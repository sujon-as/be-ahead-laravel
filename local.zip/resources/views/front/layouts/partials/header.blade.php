<style>
    .desktop-width {
        width: 100px !important;
    }
    /* Mobile center */
    @media (max-width: 767px) {
        .logo-wrapper {
            text-align: center;
            margin: 0 auto;
        }

        .center-logo {
            display: inline-block;
            margin: 0 auto;
        }
        .desktop-width {
            width: 100% !important;
        }
    }
</style>
<div class="header-topped">
  		<div class="container">
  			<div class="row">
  				<div class="col-md-4">
  					<div class="social-linked">
  						<ul class="list-inline">
  							<li><a href="{{ ($settings && $settings->facebook) ? $settings->facebook : '#' }}" target="_blank"><i class="fa fa-facebook"></i></a></li>
  							<li><a href="{{ ($settings && $settings->rss_feed) ? $settings->rss_feed : '#' }}" target="_blank"><i class="fa fa-rss"></i></a></li>
  							<li><a href="{{ ($settings && $settings->google_plus) ? $settings->google_plus : '#' }}" target="_blank"><i class="fa fa-google-plus"></i></a></li>
  							<li><a href="{{ ($settings && $settings->pinterest) ? $settings->pinterest : '#' }}" target="_blank"><i class="fa fa-pinterest"></i></a></li>
  							<li><a href="{{ ($settings && $settings->instagram) ? $settings->instagram : '#' }}" target="_blank"><i class="fa fa-instagram"></i></a></li>
  							<li><a href="{{ ($settings && $settings->linkedin) ? $settings->linkedin : '#' }}" target="_blank"><i class="fa fa-linkedin"></i></a></li>
  						</ul>
  					</div>
  				</div>
  				<div class="col-md-4">
  					<div class="welcm-ht text-center">
	  					<p class="ulockd-welcntxt">
                            {{ ($settings && $settings->welcome_msg)
                                ? $settings->welcome_msg
                                : "Welcome To Our Be aHand Charity Organizations"
                            }}
                        </p>
  					</div>
  				</div>
  				<div class="col-md-4">
  					<div class="welcm-ht text-right">
						<ul class="list-inline">
                            {{--
							<li>
								<div class="dropdown lang-button text-center">
									<button class="dropbtn">Language</button>
									<div class="dropdown-content">
									    <a href="#">English</a>
									    <a href="#">French</a>
									    <a href="#">Spanish</a>
									</div>
								</div>
							</li>
                            --}}
							<li>
								<a href="#">
									<div data-toggle="modal" data-target=".bs-example-modal-lg" data-whatever="@mdo">Sign In | Sign Up</div>
								</a>
		        				<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog">
		        				    <div class="modal-dialog modal-lg" role="document">
			        				    <div class="modal-content">
			        				        <div class="modal-header">
				        				        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				        				        <h4 class="modal-title text-center" id="exampleModalLabel">Login or Register</h4>
				        				        <p class="text-center">Sign in and choose your service to have access to all our service.</p>
			        				        </div>
			        				        <div class="modal-body">
				        				      	<div class="row">
				        				      		<div class="col-sm-12 col-md-6 col-lg-5 text-center hvr-float-shadow">
				        						        <form class="ulockd-login-form">
				        						        	<h3><span class="flaticon-lock"></span> Login</h3>
				        						        	<p>Enter username and password to login:</p>
				        						            <div class="form-group">
				            								    <input type="email" class="form-control" id="email" placeholder="Email">
				            								</div>
				            								<div class="form-group">
				            								    <input type="password" class="form-control" placeholder="Password">
				            								</div>
				        						            <button type="submit" class="btn btn-default ulockd-btn-thm2">Login to account</button>
				        						        </form>
				        				      		</div>
				        				      		<div class="col-sm-12 col-lg-7 hvr-float-shadow">
				        						        <form class="ulockd-reg-form text-center">
				        						        	<h3> <span class="flaticon-house-key"></span> Register</h3>
				        						        	<p>Join our community today:</p>
				        						            <div class="form-group">
				            								    <input type="text" class="form-control" id="exampleInputNamexa" placeholder="First Name">
				            								</div>
				        						            <div class="form-group">
				            								    <input type="text" class="form-control" id="exampleInputNamexb" placeholder="Last Name">
				            								</div>
				        						            <div class="form-group">
				            								    <input type="email" class="form-control" id="exampleInputEmailx" placeholder="Email">
				            								</div>
				            								<div class="form-group">
				            								    <input type="password" class="form-control" placeholder="Password">
				            								</div>
				            								<div class="form-group">
				            								    <input type="password" class="form-control" placeholder="Repeat password">
				            								</div>
				            								<div class="form-group text-center">
				            						        	<button type="submit" class="btn btn-default ulockd-btn-thm2">Sign Me Up</button>
				            								</div>
				        						        </form>
				        				      		</div>
				        				      	</div>
			        				        </div>
			        				        <!-- modal footer start here-->
			        				    </div>
		        				    </div>
		        				</div>
							</li>
						</ul>
  					</div>
  				</div>
  			</div>
  		</div>
  	</div>
  	<div class="header-middle">
  		<div class="container">
  			<div class="row">
  				<div class="col-xs-12 col-sm-6 col-lg-3 col-lg-3 text-center text-lg-start">
  					<div class="ulockd-welcm-hmddl desktop-width" >
						<a href="{{ route('home') }}" class="ulockd-main-logo">
                            <img src="{{ ($settings && $settings->logo)
                                ? asset($settings->logo)
                                : asset('front/images/header-logo.png') }}" alt=""
                                 class="img-responsive center-logo">
                        </a>
  					</div>
  				</div>
  				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
					<div class="ulockd-ohour-info style2">
						<div class="ulockd-icon pull-left text-thm2"><span class="flaticon-email-filled-closed-envelope"></span></div>
						<div class="ulockd-info">
							<h3>Mail Us</h3>
							<p class="ulockd-addrss"><strong>Email:</strong> {{ ($settings && $settings->email) ? $settings->email : 'example@example.com' }}</p>
						</div>
					</div>
  				</div>
  				<div class="col-xs-12 col-sm-6 col-lg-3 col-lg-3">
					<div class="ulockd-ohour-info style2">
						<div class="ulockd-icon pull-left text-thm2"><span class="flaticon-old-handphone"></span></div>
						<div class="ulockd-info">
							<h3>Call Us</h3>
							<p class="ulockd-addrss">{{ ($settings && $settings->phone) ? $settings->phone : '+123456789' }}</p>
						</div>
					</div>
  				</div>
  				<div class="col-xs-12 col-sm-6 col-lg-3 col-lg-3">
					<div class="ulockd-ohour-info style2">
						<div class="ulockd-icon pull-left text-thm2"><span class="flaticon-make-a-donation"></span></div>
						<div class="ulockd-info">
							<!-- Trigger the modal with a button -->
{{--							<button type="button" class="btn btn-lg ulockd-btn-thm2 ulockd-mrgn1215 ulockd-mrgn610" data-toggle="modal" data-target=".bs-example-modal-default">Donate now</button>--}}
                            <a href="{{ route('donation') }}">
                                <button type="button" class="btn btn-lg ulockd-btn-thm2 ulockd-mrgn1215 ulockd-mrgn610">Donate now</button>
                            </a>

							<!-- Modal -->
							<div id="Donation-form-modal" class="modal fade bs-example-modal-default text-left" role="dialog">
								<div class="modal-dialog">

								    <!-- Modal content-->
								    <div class="modal-content">
								    	<div class="modal-header text-center">
								        	<button type="button" class="close" data-dismiss="modal">&times;</button>
								        	<h3> <span class="flaticon-make-a-donation text-thm2"></span> DONATION FORM</h3>
								        	<p>Your Donation Can Save Lot's Of Life</p>
								    	</div>
								    	<div class="modal-body">
			        				      	<div class="row">
			        				      		<div class="col-sm-6 col-md-6 donation-form-samount">
			        				      			<h4>Select Your Amount</h4>
			        				      			<ul class="list-inline selected-amount">
			        				      				<li class="amount-box">
				        				      				<input id="radio-one" type="radio" name="payment-group">
			        				      					<label for="radio-one"> $10</label>
			        				      				</li>
			        				      				<li class="amount-box">
				        				      				<input id="radio-two" type="radio" name="payment-group">
			        				      					<label for="radio-two"> $20</label>
			        				      				</li>
			        				      				<li class="amount-box">
				        				      				<input id="radio-three" type="radio" name="payment-group">
			        				      					<label for="radio-three"> $30</label>
			        				      				</li>
			        				      				<li class="amount-box">
				        				      				<input id="radio-four" type="radio" name="payment-group">
			        				      					<label for="radio-four"> $50</label>
			        				      				</li>
			        				      				<li class="amount-box">
				        				      				<input id="radio-five" type="radio" name="payment-group">
			        				      					<label for="radio-five"> $100</label>
			        				      				</li>
			        				      			</ul>
			        				      			<h5>Would you like to make regular donations?</h5>
			        				      			<ul class="list-inline">
			        				      				<li><p>I would like to make </p></li>
			        				      				<li>
			        				      					<select name="pts" class="payment-time-selection">
																<option value="0">a one time</option>
																<option value="W">weekly</option>
																<option value="M">monthly</option>
																<option value="Y">yearly</option>
															</select>
			        				      				</li>
			        				      				<li> Donations</li>
			        				      			</ul>
			        				      		</div>
			        				      		<div class="col-sm-6 col-md-6 donation-form-samount">
			        				      			<form class="form-inline">
			        						        	<h4>Custom Amount</h4>
													    <div class="form-group">
														    <label class="sr-only" for="exampleInputAmount">Amount (in dollars)</label>
														    <div class="input-group">
														    	<div class="input-group-addon">$</div>
														    	<input type="number" class="form-control" id="exampleInputAmount" placeholder="Amount">
														    	<div class="input-group-addon">.00</div>
														    </div>
													    </div>
													</form>
			        				      		</div>
			        				      		<div class="col-sm-12 col-md-12">
			        						        <form class="donation-form donor-details">
			        						        	<h4>Donor Information</h4>
		        						        		<div class="row">
		        						        			<div class="col-md-6">
					        						            <div class="form-group">
					            								    <input type="text" class="form-control required" id="exampleInputNamex" placeholder="First Name">
					            								</div>
		        						        			</div>
		        						        			<div class="col-md-6">
					        						            <div class="form-group">
					            								    <input type="text" class="form-control required" id="exampleInputNamexx" placeholder="Last Name">
					            								</div>
		        						        			</div>
		        						        			<div class="col-md-6">
					        						            <div class="form-group">
					            								    <input type="email" class="form-control required" id="exampleInputEmailxy" placeholder="Email">
					            								</div>
		        						        			</div>
		        						        			<div class="col-md-6">
					        						            <div class="form-group">
					            								    <input type="text" class="form-control required" id="exampleInputPhone" placeholder="Phone">
					            								</div>
		        						        			</div>
		        						        			<div class="col-md-6">
					        						            <div class="form-group">
					            								    <input type="text" class="form-control required" id="exampleInputAddress" placeholder="Address line 1">
					            								</div>
		        						        			</div>
		        						        			<div class="col-md-6">
					        						            <div class="form-group">
					            								    <input type="text" class="form-control required" id="exampleInputAddress2" placeholder="Address line 2">
					            								</div>
		        						        			</div>
		        						        			<div class="col-md-6">
					        						            <div class="form-group">
					            								    <input type="text" class="form-control required" id="exampleInputCity" placeholder="City/State">
					            								</div>
		        						        			</div>
		        						        			<div class="col-md-6">
					        						            <div class="form-group">
					            								    <input type="text" class="form-control required" id="exampleInputZip" placeholder="Zipcode/Postcode">
					            								</div>
		        						        			</div>
		        						        		</div>
							                            <div class="form-group">
							                                <textarea id="form_message" name="form_message" class="form-control required" rows="4" placeholder="Additional Note" ></textarea>
							                            </div>
			            								<div class="form-group text-center">
			            						        	<button type="submit" class="btn btn-lg btn-block ulockd-btn-thm2" data-toggle="modal" data-target=".bs-example-modal-default">Donate now</button>
			            								</div>
			        						        </form>
			        				      		</div>
			        				      	</div>
								    	</div>
								    	<div class="modal-footer">
								        	<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								    	</div>
								    </div>
								</div>
							</div>
						</div>
					</div>
  				</div>
  			</div>
  		</div>
  	</div>

	<!-- Header Styles -->
	<header class="header-nav">
		<div class="main-header-nav navbar-scrolltofixed">
			<div class="container">
			    <nav class="navbar navbar-default bootsnav menu-style1">
					<!-- Start Top Search -->
			        <div class="top-search">
			            <div class="container">
			                <div class="input-group">
			                    <span class="input-group-addon"><i class="fa fa-search"></i></span>
			                    <input type="text" class="form-control" placeholder="Search">
			                    <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
			                </div>
			            </div>
			        </div>
			        <!-- End Top Search -->


			        <div class="container ulockd-pad90">
			            <!-- Start Atribute Navigation -->
			            <div class="attr-nav" style="display: none !important;">
			                <ul>
			                    <li class="dropdown">
			                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" >
			                            <i class="fa fa-shopping-bag"></i>
			                            <span class="badge">3</span>
			                        </a>
			                        <ul class="dropdown-menu cart-list">
			                            <li>
			                                <a href="#" class="photo"><img src="{{ asset('front/images/shop/s1.jpg') }}" class="cart-thumb" alt="s1.jpg" /></a>
			                                <h6><a href="#">Delica omtantur </a></h6>
			                                <p>2x - <span class="price">$99.99</span></p>
			                            </li>
			                            <li>
			                                <a href="#" class="photo"><img src="{{ asset('front/images/shop/s2.jpg') }}" class="cart-thumb" alt="s2.jpg" /></a>
			                                <h6><a href="#">Omnes ocurreret</a></h6>
			                                <p>1x - <span class="price">$33.33</span></p>
			                            </li>
			                            <li>
			                                <a href="#" class="photo"><img src="{{ asset('front/images/shop/s3.jpg') }}" class="cart-thumb" alt="s3.jpg" /></a>
			                                <h6><a href="#">Agam facilisis</a></h6>
			                                <p>2x - <span class="price">$99.99</span></p>
			                            </li>
			                            <li class="total">
			                                <span class="pull-right"><strong>Total</strong>: $0.00</span>
			                                <a href="#" class="btn btn-default btn-cart">Cart</a>
			                            </li>
			                        </ul>
			                    </li>
			                    <li class="search"><a href="#"><i class="fa fa-search"></i></a></li>
			                    <li class="side-menu"><a href="#"><i class="fa fa-bars"></i></a></li>
			                </ul>
			            </div>
			            <!-- End Atribute Navigation -->

			            <!-- Start Header Navigation -->
			            <div class="navbar-header">
			                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
			                    <i class="fa fa-bars"></i>
			                </button>
			            </div>
			            <!-- End Header Navigation -->

			            <!-- Collect the nav links, forms, and other content for toggling -->
			            <div class="collapse navbar-collapse" id="navbar-menu">
			                <ul class="nav navbar-nav navbar-left" data-in="fadeIn">
			                    <li class="">
			                        <a href="{{ route('home') }}" class="{{ Request::is('/') ? 'active' : '' }}">Home</a>
			                    </li>
			                    <li class="">
			                        <a href="{{ route('about') }}" class="{{ Request::is('about') ? 'active' : '' }}">About Us</a>
			                    </li>
			                    <li class="">
			                        <a href="{{ route('home') }}#mission" class="">Mission</a>
			                    </li>
			                    <li class="">
			                        <a href="{{ route('home') }}#vision" class="">Vision</a>
			                    </li>
			                    <li class="">
			                        <a href="{{ route('home') }}#project" class="">Our Project</a>
			                    </li>
                                <li class="">
                                    <a
                                        href="{{ route('team') }}"
                                        class="{{ Request::is('team') ? 'active' : '' }}"
                                    >
                                        Our Team
                                    </a>
                                </li>
                                <li class="">
                                    <a
                                        href="{{ route('volunteer') }}"
                                        class="{{ Request::is('volunteer') ? 'active' : '' }}"
                                    >
                                        Volunteer
                                    </a>
                                </li>
                                <li class="">
                                    <a
                                        href="{{ route('donation') }}"
                                        class="{{ Request::is('donation') ? 'active' : '' }}"
                                    >
                                        Donation
                                    </a>
                                </li>
                                <li class="">
                                    <a
                                        href="{{ route('gallery') }}"
                                        class="{{ Request::is('gallery') ? 'active' : '' }}"
                                    >
                                        Gallery
                                    </a>
                                </li>
                                <li class="">
                                    <a href="{{ route('blog') }}" class="{{ Request::is('blog') ? 'active' : '' }}">Blog</a>
                                </li>
                                <li class="">
                                    <a href="{{ route('latest-news') }}" class="{{ Request::is('latest-news') ? 'active' : '' }}">Latest News</a>
                                </li>
{{--                                <li class="">--}}
{{--                                    <a--}}
{{--                                        href="{{ route('appointment') }}"--}}
{{--                                        class="{{ Request::is('appointment') ? 'active' : '' }}"--}}
{{--                                    >--}}
{{--                                        Appointment--}}
{{--                                    </a>--}}
{{--                                </li>--}}

{{--                                <li class="">--}}
{{--                                    <a--}}
{{--                                        href="{{ route('faq') }}"--}}
{{--                                        class="{{ Request::is('faq') ? 'active' : '' }}"--}}
{{--                                    >--}}
{{--                                        Faq--}}
{{--                                    </a>--}}
{{--                                </li>--}}
{{--                                --}}
{{--                                <li class="">--}}
{{--                                    <a--}}
{{--                                        href="{{ route('contact') }}"--}}
{{--                                        class="{{ Request::is('contact') ? 'active' : '' }}"--}}
{{--                                    >--}}
{{--                                        Contact Us--}}
{{--                                    </a>--}}
{{--                                </li>--}}

                                {{--
			                    <li class="dropdown">
			                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages</a>
			                        <ul class="dropdown-menu">
										<li><a href="{{ route('appointment') }}">Appointment</a></li>
{{--										<li><a href="page-coming-soon.html">Coming Soon</a></li>
										<li><a href="{{ route('donation') }}">Donation Form</a></li>
{{--										<li><a href="page-error.html">Error</a></li>

					                    <li class="dropdown">
					                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Event</a>
					                        <ul class="dropdown-menu">
												<li><a href="page-event-grid.html">Event Grid</a></li>
												<li><a href="page-event-list.html">Event List</a></li>
												<li><a href="page-event-single.html">Event Single</a></li>
					                        </ul>
					                    </li>
										<li><a href="{{ route('faq') }}">Faq</a></li>
					                    <li class="dropdown">
					                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Google Calendar</a>
					                        <ul class="dropdown-menu">
												<li><a href="page-fullcalendar.html">Monthly Event</a></li>
												<li><a href="page-fullcalendar2.html">Weekly Event</a></li>
					                        </ul>
					                    </li>
                                        <li><a href="{{ route('gallery') }}">Gallery</a></li>
					                    <li class="dropdown">
					                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Gallery</a>
					                        <ul class="dropdown-menu">
												<li><a href="page-gallery.html">Gallery One</a></li>
												<li><a href="page-gallery2.html">Gallery Two</a></li>
												<li><a href="page-gallery3.html">Gallery Three</a></li>
					                        </ul>
					                    </li>
					                    <li class="dropdown">
					                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pricing</a>
					                        <ul class="dropdown-menu">
												<li><a href="page-pricing.html">Pricing One</a></li>
												<li><a href="page-pricing2.html">Pricing Two</a></li>
					                        </ul>
					                    </li>
					                    <li class="dropdown">
					                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Shop</a>
					                        <ul class="dropdown-menu">
												<li><a href="page-shop.html">Our Shop</a></li>
												<li><a href="page-product-details.html">Product Details</a></li>
												<li><a href="page-shoping-cart.html">Shopping Cart</a></li>
												<li><a href="page-shoping-checkout.html">Shopping Checkout</a></li>
					                        </ul>
					                    </li>
										<li><a href="page-sitemap.html">Sitemap</a></li>
										<li><a href="page-under-construction.html">Under Construction</a></li>

			                        </ul>
			                    </li>
			                    <li class="dropdown">
			                        <a href="{{ route('contact') }}" class="">Contact Us</a>

			                        <ul class="dropdown-menu">
										<li><a href="page-contact.html">Contact Us</a></li>
										<li><a href="page-contact2.html">Contact Us Two</a></li>
			                        </ul>

			                    </li>
                                --}}
                                {{--
			                    <li class="dropdown megamenu-fw">
			                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Megamenu</a>
			                        <ul class="dropdown-menu megamenu-content" role="menu">
			                            <li>
			                                <div class="row">
			                                    <div class="col-menu col-md-3">
			                                        <h4 class="title">Blog Classic/Single</h4>
			                                        <div class="content">
			                                            <ul class="menu-col">
			                                                <li><a href="blog-signle-left-sidebar.html">Blog Single Sidebar left</a></li>
			                                                <li><a href="blog-left-sidebar.html">Blog Sidebar left</a></li>
			                                                <li><a href="blog-right-sidebar.html">Blog Sidebar Right</a></li>
			                                                <li><a href="blog-sidebar-less.html">Blog Sidebar Less</a></li>
			                                            </ul>
			                                        </div>
			                                    </div><!-- end col-3 -->
			                                    <div class="col-menu col-md-3">
			                                        <h4 class="title">Shop Page</h4>
			                                        <div class="content">
			                                            <ul class="menu-col">
			                                                <li><a href="page-shop.html">Our Shop</a></li>
			                                                <li><a href="page-product-details.html">Product Details</a></li>
			                                                <li><a href="page-shoping-cart.html">Shopping Cart</a></li>
			                                                <li><a href="page-shoping-checkout.html">Shopping Checkout</a></li>
			                                            </ul>
			                                        </div>
			                                    </div><!-- end col-3 -->
			                                    <div class="col-menu col-md-3">
			                                        <h4 class="title">Our Gallery</h4>
			                                        <div class="content">
			                                            <ul class="menu-col">
			                                                <li><a href="page-gallery.html" target="_blank">Gallery One</a></li>
			                                                <li><a href="page-gallery2.html" target="_blank">Gallery Two</a></li>
			                                                <li><a href="page-gallery3.html" target="_blank">Gallery Three</a></li>
			                                                <li><a href="shortcode-buttons.html">Sitemap</a></li>
			                                            </ul>
			                                        </div>
			                                    </div>
			                                    <div class="col-menu col-md-3">
			                                        <h4 class="title">Video Campaign</h4>
			                                        <div class="content">
			                                            <ul class="menu-col">
			                                                <li>
																<div class="ulockd-project-sm-thumb">
																	<iframe src="https://player.vimeo.com/video/16405052?title=0&amp;byline=0&amp;portrait=0&amp;color=f2f2ea" width="140" height="120" allowfullscreen></iframe>
																</div>
			                                                </li>
			                                            </ul>
			                                        </div>
			                                    </div><!-- end col-3 -->
			                                </div><!-- end row -->
			                            </li>
					                </ul>
			                    </li>
                                --}}
			                </ul>
			            </div><!-- /.navbar-collapse -->
			        </div>


			        <!-- Start Side Menu -->
			        <div class="side ulockd-bgthm">
			            <a href="#" class="close-side"><i class="fa fa-times"></i></a>
			            <div class="widget">
			                <h4 class="title">Custom Pages</h4>
			                <ul class="link">
			                    <li><a href="#">About</a></li>
			                    <li><a href="#">Services</a></li>
			                    <li><a href="#">Blog</a></li>
			                    <li><a href="#">Portfolio</a></li>
			                    <li><a href="#">Contact</a></li>
			                </ul>
			            </div>
			            <div class="widget">
			                <h4 class="title">Additional Links</h4>
			                <ul class="link">
			                    <li><a href="#">Retina Homepage</a></li>
			                    <li><a href="#">New Page Examples</a></li>
			                    <li><a href="#">Parallax Sections</a></li>
			                    <li><a href="#">Shortcode Central</a></li>
			                    <li><a href="#">Ultimate Font Collection</a></li>
			                    <li><img title="Facebook Feed With Client File" class="img-responsive ulockd-mrgn1210" src="{{ asset('front/images/resource/image3.png') }}" alt="image3.png"></li>
			                </ul>
			            </div>
			        </div>
			        <!-- End Side Menu -->
			    </nav>
			</div>
		</div>
	</header>
