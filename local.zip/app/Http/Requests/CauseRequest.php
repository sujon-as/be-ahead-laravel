<?php

namespace App\Http\Requests;

use App\Models\Cause;
use Illuminate\Foundation\Http\FormRequest;

class CauseRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        // Get the route name and apply null-safe operator
        $routeName = $this->route()?->getName();

        $data = $this->route('front-cause');
        $id = $data?->id ?? null;

        if ($routeName === 'front-recent-causes.update') {
            return Cause::updateRules();
        }

        if ($routeName === 'cause-status-update') {
            return Cause::causeStausUpdateRules();
        }

        if ($routeName === 'rcause-status-update') {
            return Cause::rCauseStausUpdateRules();
        }

        return Cause::rules($id);
    }
}
