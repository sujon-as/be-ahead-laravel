<?php

namespace App\Http\Controllers;

use App\Http\Requests\AppointmentRequest;
use App\Http\Requests\DonationRequest;
use App\Http\Requests\MessageRequest;
use App\Http\Requests\VolunteerRequest;
use App\Models\AboutUs;
use App\Models\Appointment;
use App\Models\AppointmentTitle;
use App\Models\Award;
use App\Models\AwardTitle;
use App\Models\Blog;
use App\Models\Cause;
use App\Models\CauseTitle;
use App\Models\Donation;
use App\Models\Faq;
use App\Models\FaqTitle;
use App\Models\Feature;
use App\Models\Gallery;
use App\Models\GalleryCategory;
use App\Models\GalleryImage;
use App\Models\Message;
use App\Models\Mission;
use App\Models\MissionTitle;
use App\Models\News;
use App\Models\Project;
use App\Models\ProjectTitle;
use App\Models\RecentCause;
use App\Models\RecentCauseTitle;
use App\Models\Slider;
use App\Models\Team;
use App\Models\Vision;
use App\Models\Volunteer;
use App\Models\VolunteerTitle;
use App\Models\WhyChooseUs;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class FrontController extends Controller
{
    public function index()
    {
        $sliders = Slider::where('status', 'Active')->get();
        $features = Feature::where('status', 'Active')->get();
        $causeTitles = CauseTitle::get();
        $causes = Cause::where('status', 'Active')->get();
        $recentCauseTitles = RecentCauseTitle::first();
        $recentCauses = RecentCause::where('status', 'Active')->get();
        $whyChooseUs = WhyChooseUs::first();
        $aboutUs = AboutUs::first();
//        $gallery = Gallery::first();
//        $galleryCategories = GalleryCategory::get();
        $missionTitle = MissionTitle::first();
        $missions = Mission::where('status', 'Active')->get();
        $projectTitle = ProjectTitle::first();
        $projects = Project::get();
        $volunteers = Volunteer::where('status', 'Active')->get();
        $awardTitle = AwardTitle::first();
        $awards = Award::get();
        $vision = Vision::first();

        $gallery = Gallery::first();
        $galleryCategories = GalleryCategory::all();
        $images = GalleryImage::with('category')->get();
//        dd($projects);

        return view('front.index', compact(
            'sliders',
             'features',
             'causeTitles',
             'causes',
             'recentCauseTitles',
             'recentCauses',
             'whyChooseUs',
             'aboutUs',
             'gallery',
             'galleryCategories',
             'missionTitle',
             'missions',
             'projectTitle',
             'projects',
             'volunteers',
             'awardTitle',
             'awards',
             'vision',
             'images',
        ));
    }
    public function homeGalleryAll()
    {
        $images = GalleryImage::with('category')->get();
        return view('front.partials.home-gallery-items', compact('images'));
    }

    public function homeGalleryByCategory($id)
    {
        $images = GalleryImage::with('category')
            ->where('gallery_category_id', $id)
            ->get();

        return view('front.partials.home-gallery-items', compact('images'));
    }

    public function about()
    {
        $aboutUs = AboutUs::first();
        return view('front.about', compact('aboutUs'));
    }

    public function contact()
    {
        $awardTitle = AwardTitle::first();
        return view('front.contact', compact('awardTitle'));
    }

    public function causes()
    {
        return view('front.causes');
    }

    public function events()
    {
        return view('front.events');
    }

    public function gallery()
    {
        $gallery = Gallery::first();
        $galleryCategories = GalleryCategory::get();

        return view('front.gallery', compact('gallery', 'galleryCategories'));
    }

    public function team()
    {
        $teams = Team::where('status', 'Active')->get();
        return view('front.team', compact('teams'));
    }

    public function volunteer()
    {
        $volunteerTitle = VolunteerTitle::first();
        return view('front.volunteer', compact('volunteerTitle'));
    }

    public function appointment()
    {
        $faqTitle = FaqTitle::first();
        $faqs = Faq::get();
        $awardTitle = AwardTitle::first();
        $volunteers = Volunteer::where('status', 'Active')->get();
        $appointmentTitle = AppointmentTitle::first();
        return view('front.appointment', compact(
            'faqTitle',
            'faqs',
            'volunteers',
            'appointmentTitle',
            'awardTitle'
        ));
    }

    public function donation()
    {
        $causeTitles = CauseTitle::get();
        $causes = Cause::get();
        return view('front.donation', compact('causes', 'causeTitles'));
    }

    public function faq()
    {
        $faqTitle = FaqTitle::first();
        $faqs = Faq::get();
        return view('front.faq', compact('faqTitle', 'faqs'));
    }

    public function blog()
    {
        $blogs = Blog::where('status', 'Active')->get();
        return view('front.blog', compact('blogs'));
    }

    public function news()
    {
        $news = News::where('status', 'Active')->get();
        return view('front.news', compact('news'));
    }

    public function volunteerReg(VolunteerRequest $request)
    {
        DB::beginTransaction();
        try
        {
            // Handle file upload
            $filePath = null;
            if ($request->hasFile('image')) {
                $filePath = storeFile(
                    $request->file('image'),
                    'vr_images',
                    'vrImage_'
                );
            }

            $data = new Volunteer();
            $data->f_name = $request->f_name;
            $data->l_name = $request->l_name;
            $data->phone = $request->phone;
            $data->email = $request->email;
            $data->address = $request->address;
            $data->city = $request->city;
            $data->state = $request->state;
            $data->zip = $request->zip;
            $data->country = $request->country;
            $data->image = $filePath;
            $data->status = 'Inactive';
            $data->save();

            DB::commit();

            $notification=array(
                'message' => "Registration Successfully, Please wait for admin approval.",
                'alert-type' => "success",
            );

            return redirect()->route('volunteer')->with($notification);

        } catch(Exception $e) {
            DB::rollback();

            // Log the error
            Log::error('Error in store: ', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
                'line' => $e->getLine()
            ]);

            $notification=array(
                'message' => 'Something went wrong!!!',
                'alert-type' => 'error'
            );

            return redirect()->route('volunteer')->with($notification);
        }
    }
    public function appointmentSubmit(AppointmentRequest $request)
    {
        DB::beginTransaction();
        try
        {
            $data = new Appointment();
            $data->name = trim($request->name);
            $data->email = trim($request->email);
            $data->phone = trim($request->phone);
            $data->date = trim($request->date);
            $data->message = trim($request->message);
            $data->save();

            DB::commit();

            $notification=array(
                'message' => "Appointment submitted Successfully, Please wait for admin response.",
                'alert-type' => "success",
            );

            return redirect()->route('appointment')->with($notification);

        } catch(Exception $e) {
            DB::rollback();

            // Log the error
            Log::error('Error in store: ', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
                'line' => $e->getLine()
            ]);

            $notification=array(
                'message' => 'Something went wrong!!!',
                'alert-type' => 'error'
            );

            return redirect()->route('appointment')->with($notification);
        }
    }
    public function messageSubmit(MessageRequest $request)
    {
        DB::beginTransaction();
        try
        {
            $data = new Message();
            $data->name = trim($request->name);
            $data->email = trim($request->email);
            $data->subject = trim($request->subject);
            $data->message = trim($request->message);
            $data->save();

            DB::commit();

            $notification=array(
                'message' => "Message send Successfully.",
                'alert-type' => "success",
            );

            return redirect()->route('contact')->with($notification);

        } catch(Exception $e) {
            DB::rollback();

            // Log the error
            Log::error('Error in store: ', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
                'line' => $e->getLine()
            ]);

            $notification=array(
                'message' => 'Something went wrong!!!',
                'alert-type' => 'error'
            );

            return redirect()->route('contact')->with($notification);
        }
    }
    public function donationSubmit(DonationRequest $request)
    {
        DB::beginTransaction();
        try
        {
            // Handle file upload
            $filePath = null;
            if ($request->hasFile('img')) {
                $filePath = storeFile(
                    $request->file('img'),
                    'dss_images',
                    'dssImage_'
                );
            }

            $data = new Donation();
            $data->amount    = $request->amount;
            $data->pts       = trim($request->pts);
            $data->f_name    = trim($request->f_name);
            $data->l_name    = trim($request->l_name);
            $data->email     = trim($request->email);
            $data->phone     = trim($request->phone);
            $data->address_1 = trim($request->address_1);
            $data->address_2 = trim($request->address_2);
            $data->city      = trim($request->city);
            $data->zip       = trim($request->zip);
            $data->note      = trim($request->note);
            $data->img       = $filePath;
            $data->save();

            DB::commit();

            $notification=array(
                'message' => "Donation send Successfully.",
                'alert-type' => "success",
            );

            return redirect()->route('donation')->with($notification);

        } catch(Exception $e) {
            DB::rollback();

            // Log the error
            Log::error('Error in store: ', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
                'line' => $e->getLine()
            ]);

            $notification=array(
                'message' => 'Something went wrong!!!',
                'alert-type' => 'error'
            );

            return redirect()->route('contact')->with($notification);
        }
    }
    public function causeDetails($id)
    {
        $cause = Cause::findOrFail($id);

        return view('front.cause-details', compact('cause'));
    }
    public function recentCauseDetails($id)
    {
        $cause = RecentCause::findOrFail($id);

        return view('front.recent-cause-details', compact('cause'));
    }
    public function projectDetails($id)
    {
        $cause = Project::findOrFail($id);

        return view('front.project-details', compact('cause'));
    }
    public function missionDetails($id)
    {
        $cause = Mission::findOrFail($id);

        return view('front.mission-details', compact('cause'));
    }
    public function teamDetails($id)
    {
        $cause = Team::findOrFail($id);

        return view('front.team-details', compact('cause'));
    }
    public function visionDetails()
    {
        $cause = Vision::first();

        return view('front.vision-details', compact('cause'));
    }
    public function blogDetails($id)
    {
        $cause = Blog::findOrFail($id);

        return view('front.blog-details', compact('cause'));
    }
    public function newsDetails($id)
    {
        $cause = News::findOrFail($id);

        return view('front.news-details', compact('cause'));
    }
}
